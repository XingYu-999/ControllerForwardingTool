// Package ns2pro provides a Nintendo Switch 2 Pro Controller compatible HID device.
package ns2pro

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"sync"

	"github.com/Alia5/VIIPER/device"
	"github.com/Alia5/VIIPER/usb"
	"github.com/Alia5/VIIPER/usbip"
)

type NS2Pro struct {
	inputCh         chan struct{}
	bulkCh          chan struct{}
	stateMu         sync.Mutex
	inputState      *InputState
	metaState       *MetaState
	outputMu        sync.RWMutex
	outputCallback  func(OutputState)
	outputVersion   uint64
	descriptor      usb.Descriptor
	inputIntervalMs uint8
	sourcePaced     bool

	protoMu           sync.Mutex
	activeReportID    uint8
	featureMask       uint8
	featureFlags      uint8
	usbReportsEnabled bool
	reportCounter32   uint32
	reportCounter8    uint8
	lastMotionTS      uint32
	bulkInQueue       [][]byte
}

func New(o *device.CreateOptions) (*NS2Pro, error) {
	metaState := defaultMetaState()
	if o != nil && o.DeviceSpecific != "" {
		var newMeta MetaState
		if err := json.Unmarshal([]byte(o.DeviceSpecific), &newMeta); err != nil {
			return nil, fmt.Errorf("invalid device specific JSON: %w", err)
		}
		if newMeta.SerialNumber != "" {
			metaState.SerialNumber = newMeta.SerialNumber
		}
		if newMeta.BatteryLevel != 0 {
			metaState.BatteryLevel = newMeta.BatteryLevel
		}
		if newMeta.Charging {
			metaState.Charging = true
		}
		if newMeta.ExternalPower {
			metaState.ExternalPower = true
		}
		if newMeta.BatteryVolts != 0 {
			metaState.BatteryVolts = newMeta.BatteryVolts
		}
		if newMeta.InputIntervalMs != 0 {
			metaState.InputIntervalMs = newMeta.InputIntervalMs
		}
		metaState.SourcePaced = newMeta.SourcePaced
	}

	inputCh := make(chan struct{}, 1)
	inputCh <- struct{}{}
	initialInput := defaultInputState()
	d := &NS2Pro{
		inputCh:         inputCh,
		bulkCh:          make(chan struct{}, 1),
		inputState:      initialInput,
		metaState:       metaState,
		descriptor:      MakeDescriptor(),
		inputIntervalMs: metaState.InputIntervalMs,
		sourcePaced:     metaState.SourcePaced,
		activeReportID:  ReportIDPro,
		featureFlags:    FeatureButtons | FeatureSticks,
	}
	serialEnding := DefaultSerialEnding
	if len(metaState.SerialNumber) >= 2 {
		serialEnding = metaState.SerialNumber[len(metaState.SerialNumber)-2:]
	}
	d.descriptor.Strings[3] = serialEnding
	if len(d.descriptor.Interfaces) > 0 && len(d.descriptor.Interfaces[0].Endpoints) > 0 {
		d.descriptor.Interfaces[0].Endpoints[0].BInterval = metaState.InputIntervalMs
	}

	if o != nil {
		if o.IDVendor != nil {
			d.descriptor.Device.IDVendor = *o.IDVendor
		}
		if o.IDProduct != nil {
			d.descriptor.Device.IDProduct = *o.IDProduct
		}
	}
	return d, nil
}

func (d *NS2Pro) SetOutputCallback(f func(OutputState)) func() {
	d.outputMu.Lock()
	d.outputVersion++
	version := d.outputVersion
	d.outputCallback = f
	d.outputMu.Unlock()

	return func() {
		d.outputMu.Lock()
		if d.outputVersion == version {
			d.outputCallback = nil
		}
		d.outputMu.Unlock()
	}
}

func (d *NS2Pro) UpdateInputState(state InputState) {
	d.stateMu.Lock()
	d.inputState = &state
	d.stateMu.Unlock()
	d.signalInputReady()
}

func (d *NS2Pro) SetMetaState(meta MetaState) {
	d.stateMu.Lock()
	defer d.stateMu.Unlock()
	d.metaState = &meta
	if d.descriptor.Strings != nil {
		serialEnding := DefaultSerialEnding
		if len(meta.SerialNumber) >= 2 {
			serialEnding = meta.SerialNumber[len(meta.SerialNumber)-2:]
		}
		d.descriptor.Strings[3] = serialEnding
	}
}

func (d *NS2Pro) HandleTransfer(ctx context.Context, ep uint32, dir uint32, out []byte) []byte {
	switch {
	case dir == usbip.DirIn && ep == 1:
		if d.reportsEnabled() {
			if d.sourcePaced {
				select {
				case <-ctx.Done():
					return nil
				case <-d.inputCh:
				}
			}
			return d.nextInputReport()
		}
		for {
			select {
			case <-ctx.Done():
				if errors.Is(ctx.Err(), context.DeadlineExceeded) && d.reportsEnabled() {
					return d.nextInputReport()
				}
				return nil
			case <-d.inputCh:
				if d.reportsEnabled() {
					return d.nextInputReport()
				}
			}
		}
	case dir == usbip.DirIn && ep == 2:
		for {
			if resp := d.popBulkIn(); resp != nil {
				return resp
			}
			select {
			case <-ctx.Done():
				return nil
			case <-d.bulkCh:
			}
		}
	case dir == usbip.DirOut && ep == 1:
		d.handleOutputReport(out)
	case dir == usbip.DirOut && ep == 2:
		d.handleBulkOut(out)
	}
	return nil
}

func (d *NS2Pro) HandleControl(bmRequestType, bRequest uint8, wValue, wIndex uint16, wLength uint16, data []byte) ([]byte, bool) {
	reportType := uint8(wValue >> 8)
	reportID := uint8(wValue)

	if bmRequestType == hidClassRequestIn && bRequest == hidGetReport && reportType == reportTypeInput {
		switch reportID {
		case ReportIDCommon, ReportIDPro, 0:
			return d.inputReportForID(reportID), true
		}
	}

	if bmRequestType == hidClassRequestOut && bRequest == hidSetReport && reportType == reportTypeOutput && reportID == ReportIDOutput {
		d.handleOutputReport(data)
		return nil, true
	}

	if isAudioClassRequest(bmRequestType) {
		switch bRequest {
		case audioSetCur:
			return nil, true
		case audioGetCur, audioGetMin, audioGetMax, audioGetRes:
			return make([]byte, wLength), true
		}
	}

	return nil, false
}

func isAudioClassRequest(bmRequestType uint8) bool {
	return bmRequestType&requestTypeMask == requestClass &&
		(bmRequestType&recipientMask == recipientIface || bmRequestType&recipientMask == recipientEndpoint)
}

func (d *NS2Pro) GetDescriptor() *usb.Descriptor {
	return &d.descriptor
}

func (d *NS2Pro) GetDeviceSpecificArgs() map[string]any {
	d.stateMu.Lock()
	defer d.stateMu.Unlock()
	if d.metaState == nil {
		return map[string]any{}
	}
	b, err := json.Marshal(d.metaState)
	if err != nil {
		return map[string]any{}
	}
	var out map[string]any
	if err := json.Unmarshal(b, &out); err != nil {
		return map[string]any{}
	}
	return out
}

func (d *NS2Pro) reportsEnabled() bool {
	d.protoMu.Lock()
	defer d.protoMu.Unlock()
	return d.usbReportsEnabled
}

func (d *NS2Pro) nextInputReport() []byte {
	d.protoMu.Lock()
	reportID := d.activeReportID
	d.protoMu.Unlock()
	return d.inputReportForID(reportID)
}

func (d *NS2Pro) inputReportForID(reportID uint8) []byte {
	d.stateMu.Lock()
	st := *d.inputState
	meta := *d.metaState
	d.stateMu.Unlock()

	d.protoMu.Lock()
	if reportID == 0 {
		reportID = d.activeReportID
	}
	features := d.featureFlags
	var report []byte
	switch reportID {
	case ReportIDCommon:
		intervalMs := uint32(d.inputIntervalMs)
		if intervalMs == 0 {
			intervalMs = 1
		}
		d.reportCounter32 += intervalMs
		var motionTS uint32
		if features&FeatureIMU != 0 {
			// A wired NS2 Pro advances both clocks from its endpoint cadence,
			// independently of host scheduling jitter. At bInterval=4 ms the
			// report counter steps by 4 and the motion clock by 4000 us.
			d.lastMotionTS += intervalMs * 1000
			motionTS = d.lastMotionTS
		}
		report = st.buildCommonReport(d.reportCounter32, motionTS, features, meta)
	default:
		d.reportCounter8++
		report = st.buildProReport(d.reportCounter8, features, meta)
	}
	d.protoMu.Unlock()
	return report
}

func (d *NS2Pro) signalInputReady() {
	select {
	case d.inputCh <- struct{}{}:
	default:
	}
}

func (d *NS2Pro) serialNumber() string {
	d.stateMu.Lock()
	defer d.stateMu.Unlock()
	if d.metaState == nil {
		return ""
	}
	return d.metaState.SerialNumber
}

func (d *NS2Pro) handleOutputReport(out []byte) {
	if len(out) == 0 {
		return
	}

	payload := out
	if out[0] == ReportIDOutput {
		payload = out[1:]
	} else if len(out) != OutputRumbleSize {
		return
	}
	if len(payload) < OutputRumbleSize {
		return
	}

	feedback := OutputState{}
	copy(feedback.LeftRumble[:], payload[0:16])
	copy(feedback.RightRumble[:], payload[16:32])
	feedback.Flags = OutputFlagRumble
	d.emitOutput(feedback)
}

func (d *NS2Pro) emitOutput(feedback OutputState) {
	d.outputMu.RLock()
	callback := d.outputCallback
	d.outputMu.RUnlock()
	if callback != nil {
		callback(feedback)
	}
}

func (d *NS2Pro) enqueueResponse(resp []byte) {
	d.protoMu.Lock()
	d.bulkInQueue = append(d.bulkInQueue, append([]byte(nil), resp...))
	d.protoMu.Unlock()
	select {
	case d.bulkCh <- struct{}{}:
	default:
	}
}

func (d *NS2Pro) popBulkIn() []byte {
	d.protoMu.Lock()
	defer d.protoMu.Unlock()
	if len(d.bulkInQueue) == 0 {
		return nil
	}
	chunk := d.bulkInQueue[0]
	d.bulkInQueue = d.bulkInQueue[1:]
	return append([]byte(nil), chunk...)
}

func commandHeader(cmd, seq, sub uint8) []byte {
	return []byte{cmd, 0x01, seq, sub, 0x10, 0x78, 0x00, 0x00}
}
